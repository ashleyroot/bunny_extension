class RabbitPet {
  constructor() {
    this.element = document.createElement('div');
    this.element.className = 'rabbit-pet right';
    this.element.style.width = '300px';  // 增加到300px
    this.element.style.height = '300px'; // 增加到300px
    
    // 创建图片元素
    this.image = document.createElement('img');
    this.image.src = chrome.runtime.getURL('images/run_1_head_right.png');  // 初始使用头朝右的图片
    this.image.style.width = '100%';
    this.image.style.height = '100%';
    this.image.style.objectFit = 'contain';
    
    // 添加图片加载错误处理
    this.image.onerror = () => {
      console.error('Failed to load image:', this.image.src);
      // 如果图片加载失败，尝试使用备用图片
      this.image.src = chrome.runtime.getURL('images/run_1.png');
    };
    
    // 创建对话气泡
    this.speechBubble = document.createElement('div');
    this.speechBubble.className = 'speech-bubble';
    this.element.appendChild(this.speechBubble);
    
    this.element.appendChild(this.image);
    document.body.appendChild(this.element);
    
    this.x = Math.random() * (window.innerWidth - 300);  // 调整边界计算
    this.y = window.innerHeight - 300;  // 调整底部位置，从320改为300
    this.direction = 1;
    this.isMoving = true;  // 默认开始移动
    this.happiness = 100;
    this.hunger = 0;
    this.normalSpeed = 3;
    this.currentSpeed = this.normalSpeed;
    
    // 设置初始可见性为完全可见
    this.element.style.opacity = '1';
    
    this.updatePosition();
    this.startMoving();
    this.startHungerIncrease();
    this.startRandomActions();  // 开始随机动作

    // 添加窗口大小改变的监听
    window.addEventListener('resize', () => {
      if (this.x > window.innerWidth - 300) {  // 调整边界检查
        this.x = window.innerWidth - 300;
      }
      if (this.x < 0) {
        this.x = 0;
      }
      this.updatePosition();
    });

    // 添加调试信息
    console.log('Rabbit pet created');
    console.log('Image source:', this.image.src);
  }

  showSpeech(text) {
    this.speechBubble.textContent = text;
    this.speechBubble.style.display = 'block';
    setTimeout(() => {
      this.speechBubble.style.display = 'none';
    }, 3000);
  }

  // 新增：随机动作
  startRandomActions() {
    setInterval(() => {
      if (this.isMoving && Math.random() < 0.3) {  // 30%的概率执行动作
        const action = Math.random() < 0.5 ? 'play' : 'feed';
        this[action]();
      }
    }, 3000);  // 每3秒判断一次是否执行随机动作
  }

  updatePosition() {
    this.element.style.left = `${this.x}px`;
    this.element.style.top = `${this.y}px`;
    
    // 更新方向朝向
    if (this.direction > 0) {
      this.element.classList.remove('left');
      this.element.classList.add('right');
      const newSrc = chrome.runtime.getURL('images/run_1_head_right.png');
      console.log('Loading right image:', newSrc);
      this.image.src = newSrc;
    } else {
      this.element.classList.remove('right');
      this.element.classList.add('left');
      const newSrc = chrome.runtime.getURL('images/run_1_head_left.png');
      console.log('Loading left image:', newSrc);
      this.image.src = newSrc;
    }
  }

  startMoving() {
    setInterval(() => {
      if (this.isMoving) {
        this.x += this.currentSpeed * this.direction;
        
        // 碰到边界就改变方向
        if (this.x > window.innerWidth - 300) {
          this.direction = -1;
        } else if (this.x < 0) {
          this.direction = 1;
        }
        
        this.updatePosition();
      }
    }, 50);
  }

  startHungerIncrease() {
    setInterval(() => {
      if (this.isMoving) {
        this.hunger = Math.min(100, this.hunger + 1);
        this.happiness = Math.max(0, this.happiness - 0.5);
      }
    }, 5000);
  }

  feed(foodType) {
    if (this.hunger > 0) {
      this.hunger = Math.max(0, this.hunger - 30);
      this.happiness = Math.min(100, this.happiness + 10);
      
      switch(foodType) {
        case 'grass':
          this.showSpeech('怎么又给我吃草啊！');
          this.element.classList.add('eating');
          break;
        case 'pellets':
          this.showSpeech('好吃，能不能再来点？');
          this.element.classList.add('eating');
          break;
        case 'hairball':
          this.currentSpeed = this.normalSpeed * 3;
          this.element.classList.add('playing');
          setTimeout(() => {
            this.currentSpeed = this.normalSpeed;
            this.element.classList.remove('playing');
          }, 5000);
          break;
      }
      
      setTimeout(() => {
        this.element.classList.remove('eating');
      }, 2000);
    }
  }

  play() {
    this.happiness = Math.min(100, this.happiness + 20);
    this.element.classList.add('playing');
    setTimeout(() => {
      this.element.classList.remove('playing');
    }, 2000);
  }

  toggle() {
    this.isMoving = !this.isMoving;
    if (this.isMoving) {
      this.element.style.display = 'block';
    } else {
      this.element.style.display = 'none';
    }
  }
}

// 等待页面完全加载后再创建兔子
window.addEventListener('load', () => {
  // 创建兔子实例
  let rabbit = new RabbitPet();

  // 监听来自popup的消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch(request.action) {
      case 'feed':
        rabbit.feed(request.foodType);
        break;
      case 'play':
        rabbit.play();
        break;
      case 'toggle':
        rabbit.toggle();
        break;
    }
  });
});

// 创建兔子元素
const bunny = document.createElement('div');
bunny.className = 'bunny';
bunny.innerHTML = `
    <img src="${chrome.runtime.getURL('images/avatar.png')}" alt="bunny" class="bunny-image">
    <div class="bunny-animation">
        <img src="${chrome.runtime.getURL('images/run_0.png')}" alt="bunny run frame 1" class="bunny-frame">
        <img src="${chrome.runtime.getURL('images/run_1.png')}" alt="bunny run frame 2" class="bunny-frame">
    </div>
    <div class="speech-bubble"></div>
`;

// 添加兔子样式
const style = document.createElement('style');
style.textContent = `
    .bunny {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 100px;
        height: 100px;
        z-index: 10000;
        cursor: pointer;
        transition: transform 0.3s;
    }

    .bunny:hover {
        transform: scale(1.1);
    }

    .bunny-image {
        width: 100%;
        height: 100%;
        object-fit: contain;
    }

    .bunny-animation {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: none;
    }

    .bunny-frame {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: contain;
        opacity: 0;
    }

    .bunny-frame:first-child {
        animation: runFrame1 0.2s infinite;
    }

    .bunny-frame:last-child {
        animation: runFrame2 0.2s infinite;
    }

    @keyframes runFrame1 {
        0%, 100% { opacity: 0; }
        50% { opacity: 1; }
    }

    @keyframes runFrame2 {
        0%, 100% { opacity: 1; }
        50% { opacity: 0; }
    }

    .speech-bubble {
        position: absolute;
        top: -40px;
        left: 50%;
        transform: translateX(-50%);
        background-color: white;
        padding: 8px 12px;
        border-radius: 15px;
        font-size: 12px;
        color: #333;
        white-space: nowrap;
        display: none;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .speech-bubble:after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 50%;
        transform: translateX(-50%);
        border-width: 8px 8px 0;
        border-style: solid;
        border-color: white transparent transparent;
    }

    @keyframes hop {
        0% { transform: translateY(0); }
        50% { transform: translateY(-20px); }
        100% { transform: translateY(0); }
    }

    @keyframes eat {
        0% { transform: rotate(0deg); }
        25% { transform: rotate(-15deg); }
        75% { transform: rotate(15deg); }
        100% { transform: rotate(0deg); }
    }

    @keyframes happy {
        0% { transform: scale(1); }
        50% { transform: scale(1.2); }
        100% { transform: scale(1); }
    }

    @keyframes fastMove {
        0% { transform: translateX(0) translateY(0); }
        25% { transform: translateX(50px) translateY(-20px); }
        50% { transform: translateX(100px) translateY(0); }
        75% { transform: translateX(50px) translateY(-20px); }
        100% { transform: translateX(0) translateY(0); }
    }
`;

document.head.appendChild(style);
document.body.appendChild(bunny);

// 获取动画元素和静态图片
const bunnyAnimation = bunny.querySelector('.bunny-animation');
const bunnyImage = bunny.querySelector('.bunny-image');

// 显示对话气泡
function showSpeech(text) {
    const speechBubble = bunny.querySelector('.speech-bubble');
    speechBubble.textContent = text;
    speechBubble.style.display = 'block';
    setTimeout(() => {
        speechBubble.style.display = 'none';
    }, 3000);
}

// 监听来自popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch(request.action) {
        case 'feed':
            feedBunny(request.food);
            break;
        case 'play':
            playWithBunny();
            break;
        case 'toggle':
            toggleBunny();
            break;
    }
});

// 喂食动画
function feedBunny(food) {
    switch(food) {
        case 'grass':
            showSpeech('怎么又给我吃草啊！');
            bunny.style.animation = 'eat 1s ease-in-out';
            break;
        case 'pellets':
            showSpeech('好吃，能不能再来点？');
            bunny.style.animation = 'eat 1s ease-in-out';
            break;
        case 'hairball':
            // 隐藏静态图片，显示动画
            bunnyImage.style.display = 'none';
            bunnyAnimation.style.display = 'block';
            bunny.style.animation = 'fastMove 0.5s ease-in-out infinite';
            // 5秒后恢复静态图片
            setTimeout(() => {
                bunnyImage.style.display = 'block';
                bunnyAnimation.style.display = 'none';
                bunny.style.animation = '';
            }, 5000);
            break;
    }
    setTimeout(() => {
        if (food !== 'hairball') {
            bunny.style.animation = '';
        }
    }, 1000);
}

// 玩耍动画
function playWithBunny() {
    bunny.style.animation = 'hop 0.5s ease-in-out';
    setTimeout(() => {
        bunny.style.animation = '';
    }, 500);
}

// 显示/隐藏兔子
function toggleBunny() {
    bunny.style.display = bunny.style.display === 'none' ? 'block' : 'none';
}

// 点击兔子时的互动
bunny.addEventListener('click', () => {
    bunny.style.animation = 'happy 0.5s ease-in-out';
    setTimeout(() => {
        bunny.style.animation = '';
    }, 500);
}); 