document.addEventListener('DOMContentLoaded', function() {
    const feedButton = document.getElementById('feed');
    const playButton = document.getElementById('play');
    const toggleButton = document.getElementById('toggle');
    const feedOptions = document.querySelector('.feed-options');
    const statusDiv = document.querySelector('.status');
    const bunnySpeech = document.querySelector('.bunny-speech');

    // 显示兔子说话
    function showBunnySpeech(text) {
        bunnySpeech.textContent = text;
        bunnySpeech.style.display = 'block';
        setTimeout(() => {
            bunnySpeech.style.display = 'none';
        }, 3000);
    }

    // 喂食按钮点击事件
    feedButton.addEventListener('click', function() {
        feedOptions.style.display = feedOptions.style.display === 'none' ? 'block' : 'none';
    });

    // 喂食选项点击事件
    document.querySelectorAll('.feed-option').forEach(option => {
        option.addEventListener('click', function() {
            const food = this.getAttribute('data-food');
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'feed',
                    food: food
                });
            });
            feedOptions.style.display = 'none';
            
            // 根据食物类型显示不同的对话
            switch(food) {
                case 'grass':
                    showBunnySpeech('怎么又给我吃草啊！');
                    break;
                case 'pellets':
                    showBunnySpeech('好吃，能不能再来点？');
                    break;
                case 'hairball':
                    showBunnySpeech('化毛膏好甜，感觉舒服多了！');
                    break;
            }
        });
    });

    // 玩耍按钮点击事件
    playButton.addEventListener('click', function() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {action: 'play'});
        });
        showBunnySpeech('好开心！主人陪我玩！');
    });

    // 显示/隐藏按钮点击事件
    toggleButton.addEventListener('click', function() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {action: 'toggle'});
        });
    });
}); 